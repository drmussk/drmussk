# Structure Multilingue du Site Dr. Mussk

## Organisation des Fichiers

```
dr_mussk_site/
├── index.html                # Page d'accueil en français (langue par défaut)
├── about.html                # Page À propos en français
├── shop.html                 # Page Boutique en français
├── articles.html             # Page Articles en français
├── contact.html              # Page Contact en français
├── cart.html                 # Page Panier en français
├── css/
│   ├── normalize.css         # Normalisation CSS (partagé)
│   └── styles.css            # Styles principaux (partagé)
├── js/
│   ├── main.js               # JavaScript principal (partagé)
│   └── language-switcher.js  # Script de changement de langue (partagé)
├── images/                   # Images partagées
├── fonts/                    # Polices partagées
├── ar/                       # Version arabe du site
│   ├── index.html            # Page d'accueil en arabe
│   ├── about.html            # Page À propos en arabe
│   ├── shop.html             # Page Boutique en arabe
│   ├── articles.html         # Page Articles en arabe
│   ├── contact.html          # Page Contact en arabe
│   ├── cart.html             # Page Panier en arabe
│   └── css/
│       └── rtl-styles.css    # Styles spécifiques pour RTL (arabe)
└── en/                       # Version anglaise du site
    ├── index.html            # Page d'accueil en anglais
    ├── about.html            # Page À propos en anglais
    ├── shop.html             # Page Boutique en anglais
    ├── articles.html         # Page Articles en anglais
    ├── contact.html          # Page Contact en anglais
    └── cart.html             # Page Panier en anglais
```

## Stratégie Multilingue

### 1. Structure des Fichiers
- **Approche par dossiers** : Chaque langue a son propre dossier (sauf le français qui est à la racine)
- **Ressources partagées** : Les fichiers CSS, JS, images et polices sont partagés entre les langues
- **Styles spécifiques** : Un fichier CSS supplémentaire pour l'arabe (RTL)

### 2. Sélecteur de Langue
- Présent dans l'en-tête et le pied de page de chaque page
- Utilise des attributs `data-lang` pour identifier la langue cible
- Stocke la préférence de langue dans `localStorage`

### 3. Direction du Texte
- Français et anglais : direction de gauche à droite (LTR)
- Arabe : direction de droite à gauche (RTL)
- Attribut `dir="rtl"` sur l'élément HTML pour les pages en arabe
- Styles CSS spécifiques pour adapter la mise en page en RTL

### 4. Polices de Caractères
- Latin (français/anglais) : 
  - Titres : Playfair Display
  - Texte : Roboto
- Arabe : 
  - Titres : Amiri
  - Texte : Noto Sans Arabic

### 5. Traduction
- Traduction manuelle de tous les textes
- Adaptation culturelle des contenus si nécessaire
- Cohérence des URLs entre les langues

## Implémentation Technique

### Changement de Langue
Le script `language-switcher.js` gère :
- La détection de la langue actuelle
- Le changement de langue via les sélecteurs
- La redirection vers la page équivalente dans la langue choisie
- La persistance de la préférence de langue via `localStorage`

### Support RTL pour l'Arabe
Le fichier `rtl-styles.css` contient :
- Inversions de marges et de paddings
- Ajustements des alignements de texte
- Modifications des directions de flex et grid
- Adaptations des icônes et des éléments de navigation

### Considérations SEO
- Attribut `lang` sur l'élément HTML
- Balises `hreflang` pour indiquer les versions alternatives
- URLs cohérentes entre les langues
- Contenu traduit unique pour chaque langue

## Maintenance et Évolution
- Toute modification doit être répercutée dans les trois versions linguistiques
- Les nouvelles pages doivent être créées dans les trois langues
- Les ressources partagées doivent rester compatibles avec les trois langues
- Possibilité d'ajouter d'autres langues en suivant la même structure

