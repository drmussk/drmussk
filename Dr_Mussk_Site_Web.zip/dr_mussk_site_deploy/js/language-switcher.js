/**
 * Dr. Mussk Website - Language Switcher
 * Handles language switching functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    // Get current page path
    const currentPath = window.location.pathname;
    const currentPage = currentPath.split('/').pop() || 'index.html';
    
    // Get language from URL
    const currentLang = getCurrentLanguage();
    
    // Set HTML dir attribute based on language
    if (currentLang === 'ar') {
        document.documentElement.setAttribute('dir', 'rtl');
    } else {
        document.documentElement.setAttribute('dir', 'ltr');
    }
    
    // Handle language selector clicks
    const languageLinks = document.querySelectorAll('.language-selector a, .footer-language a');
    
    if (languageLinks.length > 0) {
        languageLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetLang = this.getAttribute('data-lang');
                if (!targetLang) return;
                
                // Save language preference to localStorage
                localStorage.setItem('drMusskLanguage', targetLang);
                
                // Redirect to the corresponding page in the selected language
                let targetUrl;
                
                if (targetLang === 'fr') {
                    // French is the default language, so it's in the root directory
                    targetUrl = currentLang === 'fr' ? currentPage : `/${currentPage}`;
                } else {
                    // Other languages are in their respective directories
                    targetUrl = `/${targetLang}/${currentPage}`;
                }
                
                // Handle root path case
                if (currentPath === '/' && targetLang === 'fr') {
                    targetUrl = '/index.html';
                } else if (currentPath === '/' && targetLang !== 'fr') {
                    targetUrl = `/${targetLang}/index.html`;
                }
                
                // Redirect to the target URL
                window.location.href = targetUrl;
            });
        });
    }
    
    // Function to get current language from URL
    function getCurrentLanguage() {
        const pathParts = currentPath.split('/').filter(part => part);
        
        if (pathParts.length > 0) {
            if (pathParts[0] === 'ar') return 'ar';
            if (pathParts[0] === 'en') return 'en';
        }
        
        // Default language is French
        return 'fr';
    }
});

