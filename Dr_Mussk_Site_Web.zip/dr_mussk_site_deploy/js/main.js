/**
 * Dr. Mussk Website - Main JavaScript File
 */

document.addEventListener('DOMContentLoaded', function() {
    // Mobile Menu Toggle
    const menuToggle = document.querySelector('.menu-toggle');
    const navList = document.querySelector('.nav-list');
    
    if (menuToggle && navList) {
        menuToggle.addEventListener('click', function() {
            navList.classList.toggle('active');
            
            // Animate hamburger menu
            const bars = menuToggle.querySelectorAll('.bar');
            bars.forEach(bar => bar.classList.toggle('animate'));
        });
    }
    
    // Close mobile menu when clicking outside
    document.addEventListener('click', function(event) {
        if (navList && navList.classList.contains('active') && 
            !event.target.closest('.main-nav') && 
            !event.target.closest('.menu-toggle')) {
            navList.classList.remove('active');
            
            // Reset hamburger menu animation
            const bars = document.querySelectorAll('.menu-toggle .bar');
            bars.forEach(bar => bar.classList.remove('animate'));
        }
    });
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                e.preventDefault();
                
                window.scrollTo({
                    top: targetElement.offsetTop - 80, // Adjust for header height
                    behavior: 'smooth'
                });
                
                // Close mobile menu if open
                if (navList && navList.classList.contains('active')) {
                    navList.classList.remove('active');
                    
                    // Reset hamburger menu animation
                    const bars = document.querySelectorAll('.menu-toggle .bar');
                    bars.forEach(bar => bar.classList.remove('animate'));
                }
            }
        });
    });
    
    // Add shadow to header on scroll
    const header = document.querySelector('.header');
    
    if (header) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    }
    
    // Simple form validation for contact form
    const contactForm = document.querySelector('.contact-form');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            let isValid = true;
            const requiredFields = contactForm.querySelectorAll('[required]');
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('error');
                } else {
                    field.classList.remove('error');
                }
            });
            
            // Email validation
            const emailField = contactForm.querySelector('input[type="email"]');
            if (emailField && emailField.value.trim()) {
                const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailPattern.test(emailField.value.trim())) {
                    isValid = false;
                    emailField.classList.add('error');
                }
            }
            
            if (isValid) {
                // In a real implementation, this would send the form data to a server
                // For now, we'll just show a success message
                const formMessage = document.querySelector('.form-message');
                if (formMessage) {
                    formMessage.textContent = 'Votre message a été envoyé avec succès!';
                    formMessage.classList.add('success');
                    formMessage.classList.remove('error');
                    formMessage.style.display = 'block';
                    
                    // Reset form
                    contactForm.reset();
                    
                    // Hide message after 5 seconds
                    setTimeout(() => {
                        formMessage.style.display = 'none';
                    }, 5000);
                }
            } else {
                const formMessage = document.querySelector('.form-message');
                if (formMessage) {
                    formMessage.textContent = 'Veuillez remplir tous les champs requis correctement.';
                    formMessage.classList.add('error');
                    formMessage.classList.remove('success');
                    formMessage.style.display = 'block';
                }
            }
        });
        
        // Remove error class on input
        const formInputs = contactForm.querySelectorAll('input, textarea');
        formInputs.forEach(input => {
            input.addEventListener('input', function() {
                if (this.value.trim()) {
                    this.classList.remove('error');
                }
            });
        });
    }
    
    // Simple shopping cart functionality
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    const cartCount = document.querySelector('.cart-count');
    
    if (addToCartButtons.length > 0 && cartCount) {
        // Initialize cart from localStorage or create empty cart
        let cart = JSON.parse(localStorage.getItem('drMusskCart')) || [];
        updateCartCount();
        
        addToCartButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                
                const productId = this.dataset.id;
                const productName = this.dataset.name;
                const productPrice = parseFloat(this.dataset.price);
                const productImage = this.dataset.image;
                
                // Check if product is already in cart
                const existingProduct = cart.find(item => item.id === productId);
                
                if (existingProduct) {
                    existingProduct.quantity += 1;
                } else {
                    cart.push({
                        id: productId,
                        name: productName,
                        price: productPrice,
                        image: productImage,
                        quantity: 1
                    });
                }
                
                // Save cart to localStorage
                localStorage.setItem('drMusskCart', JSON.stringify(cart));
                
                // Update cart count
                updateCartCount();
                
                // Show confirmation message
                showCartNotification(productName);
            });
        });
        
        function updateCartCount() {
            const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
            cartCount.textContent = totalItems;
            
            if (totalItems > 0) {
                cartCount.style.display = 'flex';
            } else {
                cartCount.style.display = 'none';
            }
        }
        
        function showCartNotification(productName) {
            // Create notification element if it doesn't exist
            let notification = document.querySelector('.cart-notification');
            
            if (!notification) {
                notification = document.createElement('div');
                notification.className = 'cart-notification';
                document.body.appendChild(notification);
            }
            
            // Set notification content
            notification.textContent = `${productName} a été ajouté au panier`;
            notification.classList.add('show');
            
            // Hide notification after 3 seconds
            setTimeout(() => {
                notification.classList.remove('show');
            }, 3000);
        }
    }
    
    // Language selector functionality
    const languageLinks = document.querySelectorAll('.language-selector a');
    
    if (languageLinks.length > 0) {
        languageLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                // In a real implementation, this would change the language
                // For now, we'll just update the active class
                languageLinks.forEach(l => l.classList.remove('active'));
                this.classList.add('active');
            });
        });
    }
});

