/**
 * Dr. Mussk Admin Panel
 * This script handles all the functionality of the admin panel
 */

// Global variables
let productsData = [];
let categoriesData = [];
let currentLanguage = 'fr';
let currentEditingId = null;
let confirmCallback = null;

// DOM Elements
const adminLanguageSelect = document.getElementById('adminLanguage');
const navItems = document.querySelectorAll('.admin-nav li');
const tabContents = document.querySelectorAll('.tab-content');
const productSearch = document.getElementById('productSearch');
const categoryFilter = document.getElementById('categoryFilter');
const productsTableBody = document.getElementById('productsTableBody');
const categoriesTableBody = document.getElementById('categoriesTableBody');
const addProductBtn = document.getElementById('addProductBtn');
const addCategoryBtn = document.getElementById('addCategoryBtn');
const productModal = document.getElementById('productModal');
const categoryModal = document.getElementById('categoryModal');
const confirmModal = document.getElementById('confirmModal');
const productForm = document.getElementById('productForm');
const categoryForm = document.getElementById('categoryForm');
const modalCloseButtons = document.querySelectorAll('.close');
const cancelProductBtn = document.getElementById('cancelProductBtn');
const cancelCategoryBtn = document.getElementById('cancelCategoryBtn');
const confirmYesBtn = document.getElementById('confirmYesBtn');
const confirmNoBtn = document.getElementById('confirmNoBtn');
const uploadImageBtn = document.getElementById('uploadImageBtn');
const productImage = document.getElementById('productImage');
const imagePreview = document.getElementById('imagePreview');
const tabHeaders = document.querySelectorAll('.tab-header');
const tabBodies = document.querySelectorAll('.tab-body');
const pageSelect = document.getElementById('pageSelect');
const languageSelect = document.getElementById('languageSelect');
const contentEditor = document.getElementById('contentEditor');
const saveContentBtn = document.getElementById('saveContentBtn');
const saveSettingsBtn = document.getElementById('saveSettingsBtn');

// Initialize the admin panel
document.addEventListener('DOMContentLoaded', () => {
    // Load data
    loadProducts();
    loadCategories();
    
    // Set up event listeners
    setupEventListeners();
    
    // Set language
    setLanguage(currentLanguage);
});

// Load products from JSON file
function loadProducts() {
    fetch('../products.json')
        .then(response => response.json())
        .then(data => {
            productsData = data.products;
            renderProducts();
        })
        .catch(error => {
            console.error('Error loading products:', error);
            showNotification('Erreur lors du chargement des produits', 'error');
        });
}

// Load categories from JSON file
function loadCategories() {
    fetch('../products.json')
        .then(response => response.json())
        .then(data => {
            categoriesData = data.categories;
            renderCategories();
            populateCategoryDropdowns();
        })
        .catch(error => {
            console.error('Error loading categories:', error);
            showNotification('Erreur lors du chargement des catégories', 'error');
        });
}

// Render products in the table
function renderProducts(filteredProducts = null) {
    const products = filteredProducts || productsData;
    productsTableBody.innerHTML = '';
    
    products.forEach(product => {
        const row = document.createElement('tr');
        
        // Find category name
        const category = categoriesData.find(cat => 
            cat.name.fr === product.category.fr || 
            cat.name.en === product.category.en || 
            cat.name.ar === product.category.ar
        );
        
        const categoryName = category ? category.name[currentLanguage] : product.category[currentLanguage];
        
        row.innerHTML = `
            <td>
                <img src="../${product.image}" alt="${product.name[currentLanguage]}" class="product-image">
            </td>
            <td>${product.name[currentLanguage]}</td>
            <td>${categoryName}</td>
            <td>${product.price} ${product.currency}</td>
            <td>${product.stock}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn-primary btn-icon edit-product" data-id="${product.id}" title="Modifier">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-danger btn-icon delete-product" data-id="${product.id}" title="Supprimer">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        `;
        
        productsTableBody.appendChild(row);
    });
    
    // Add event listeners to action buttons
    document.querySelectorAll('.edit-product').forEach(button => {
        button.addEventListener('click', () => editProduct(button.dataset.id));
    });
    
    document.querySelectorAll('.delete-product').forEach(button => {
        button.addEventListener('click', () => confirmDeleteProduct(button.dataset.id));
    });
}

// Render categories in the table
function renderCategories() {
    categoriesTableBody.innerHTML = '';
    
    categoriesData.forEach(category => {
        const row = document.createElement('tr');
        
        row.innerHTML = `
            <td>${category.id}</td>
            <td>${category.name.fr}</td>
            <td>${category.name.en}</td>
            <td>${category.name.ar}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn-primary btn-icon edit-category" data-id="${category.id}" title="Modifier">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-danger btn-icon delete-category" data-id="${category.id}" title="Supprimer">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        `;
        
        categoriesTableBody.appendChild(row);
    });
    
    // Add event listeners to action buttons
    document.querySelectorAll('.edit-category').forEach(button => {
        button.addEventListener('click', () => editCategory(button.dataset.id));
    });
    
    document.querySelectorAll('.delete-category').forEach(button => {
        button.addEventListener('click', () => confirmDeleteCategory(button.dataset.id));
    });
}

// Populate category dropdowns
function populateCategoryDropdowns() {
    // For filter dropdown
    categoryFilter.innerHTML = `
        <option value="all">
            ${currentLanguage === 'fr' ? 'Toutes les catégories' : 
              currentLanguage === 'en' ? 'All categories' : 
              'جميع الفئات'}
        </option>
    `;
    
    // For product form dropdown
    document.getElementById('productCategory').innerHTML = '';
    
    categoriesData.forEach(category => {
        const filterOption = document.createElement('option');
        filterOption.value = category.id;
        filterOption.textContent = category.name[currentLanguage];
        categoryFilter.appendChild(filterOption);
        
        const formOption = document.createElement('option');
        formOption.value = category.id;
        formOption.textContent = category.name[currentLanguage];
        document.getElementById('productCategory').appendChild(formOption);
    });
}

// Set up event listeners
function setupEventListeners() {
    // Navigation tabs
    navItems.forEach(item => {
        item.addEventListener('click', () => {
            navItems.forEach(i => i.classList.remove('active'));
            item.classList.add('active');
            
            const tabId = item.dataset.tab;
            tabContents.forEach(content => {
                content.classList.remove('active');
                if (content.id === tabId) {
                    content.classList.add('active');
                }
            });
        });
    });
    
    // Language switcher
    adminLanguageSelect.addEventListener('change', () => {
        setLanguage(adminLanguageSelect.value);
    });
    
    // Search and filter
    productSearch.addEventListener('input', filterProducts);
    categoryFilter.addEventListener('change', filterProducts);
    
    // Add buttons
    addProductBtn.addEventListener('click', () => showProductModal());
    addCategoryBtn.addEventListener('click', () => showCategoryModal());
    
    // Close modals
    modalCloseButtons.forEach(button => {
        button.addEventListener('click', () => {
            productModal.style.display = 'none';
            categoryModal.style.display = 'none';
            confirmModal.style.display = 'none';
        });
    });
    
    // Cancel buttons
    cancelProductBtn.addEventListener('click', () => productModal.style.display = 'none');
    cancelCategoryBtn.addEventListener('click', () => categoryModal.style.display = 'none');
    
    // Confirm modal buttons
    confirmYesBtn.addEventListener('click', () => {
        if (confirmCallback) {
            confirmCallback();
        }
        confirmModal.style.display = 'none';
    });
    
    confirmNoBtn.addEventListener('click', () => confirmModal.style.display = 'none');
    
    // Form submissions
    productForm.addEventListener('submit', saveProduct);
    categoryForm.addEventListener('submit', saveCategory);
    
    // Image upload
    uploadImageBtn.addEventListener('click', () => productImage.click());
    productImage.addEventListener('change', handleImageUpload);
    
    // Form tabs
    tabHeaders.forEach(header => {
        header.addEventListener('click', () => {
            tabHeaders.forEach(h => h.classList.remove('active'));
            header.classList.add('active');
            
            const langTab = header.dataset.langTab;
            tabBodies.forEach(body => {
                body.classList.remove('active');
                if (body.dataset.langContent === langTab) {
                    body.classList.add('active');
                }
            });
        });
    });
    
    // Content editor
    pageSelect.addEventListener('change', loadPageContent);
    languageSelect.addEventListener('change', loadPageContent);
    saveContentBtn.addEventListener('click', savePageContent);
    
    // Settings
    saveSettingsBtn.addEventListener('click', saveSettings);
    
    // Close modals when clicking outside
    window.addEventListener('click', (event) => {
        if (event.target === productModal) {
            productModal.style.display = 'none';
        }
        if (event.target === categoryModal) {
            categoryModal.style.display = 'none';
        }
        if (event.target === confirmModal) {
            confirmModal.style.display = 'none';
        }
    });
}

// Filter products based on search and category
function filterProducts() {
    const searchTerm = productSearch.value.toLowerCase();
    const categoryId = categoryFilter.value;
    
    let filtered = productsData;
    
    // Filter by search term
    if (searchTerm) {
        filtered = filtered.filter(product => 
            product.name.fr.toLowerCase().includes(searchTerm) ||
            product.name.en.toLowerCase().includes(searchTerm) ||
            product.name.ar.toLowerCase().includes(searchTerm) ||
            product.description.fr.toLowerCase().includes(searchTerm) ||
            product.description.en.toLowerCase().includes(searchTerm) ||
            product.description.ar.toLowerCase().includes(searchTerm)
        );
    }
    
    // Filter by category
    if (categoryId && categoryId !== 'all') {
        filtered = filtered.filter(product => {
            const category = categoriesData.find(cat => cat.id === categoryId);
            return category && (
                product.category.fr === category.name.fr ||
                product.category.en === category.name.en ||
                product.category.ar === category.name.ar
            );
        });
    }
    
    renderProducts(filtered);
}

// Show product modal for adding or editing
function showProductModal(productId = null) {
    currentEditingId = productId;
    const modalTitle = document.getElementById('modalTitle');
    
    // Reset form
    productForm.reset();
    imagePreview.innerHTML = '';
    
    if (productId) {
        // Edit mode
        const product = productsData.find(p => p.id === productId);
        if (!product) return;
        
        modalTitle.innerHTML = `
            <span data-lang="fr">Modifier le produit</span>
            <span data-lang="en">Edit product</span>
            <span data-lang="ar">تعديل المنتج</span>
        `;
        
        // Fill form with product data
        document.getElementById('productId').value = product.id;
        document.getElementById('productNameFr').value = product.name.fr;
        document.getElementById('productNameEn').value = product.name.en;
        document.getElementById('productNameAr').value = product.name.ar;
        document.getElementById('productDescFr').value = product.description.fr;
        document.getElementById('productDescEn').value = product.description.en;
        document.getElementById('productDescAr').value = product.description.ar;
        
        if (product.usage) {
            document.getElementById('productUsageFr').value = product.usage.fr || '';
            document.getElementById('productUsageEn').value = product.usage.en || '';
            document.getElementById('productUsageAr').value = product.usage.ar || '';
        }
        
        if (product.benefits) {
            document.getElementById('productBenefitsFr').value = product.benefits.fr ? product.benefits.fr.join('\n') : '';
            document.getElementById('productBenefitsEn').value = product.benefits.en ? product.benefits.en.join('\n') : '';
            document.getElementById('productBenefitsAr').value = product.benefits.ar ? product.benefits.ar.join('\n') : '';
        }
        
        // Find category in dropdown
        const category = categoriesData.find(cat => 
            cat.name.fr === product.category.fr || 
            cat.name.en === product.category.en || 
            cat.name.ar === product.category.ar
        );
        
        if (category) {
            document.getElementById('productCategory').value = category.id;
        }
        
        document.getElementById('productPrice').value = product.price;
        document.getElementById('productCurrency').value = product.currency;
        document.getElementById('productWeight').value = product.weight || product.volume || '';
        document.getElementById('productStock').value = product.stock;
        document.getElementById('productFeatured').checked = product.featured;
        
        // Show product image
        if (product.image) {
            const img = document.createElement('img');
            img.src = `../${product.image}`;
            img.alt = product.name[currentLanguage];
            imagePreview.appendChild(img);
        }
    } else {
        // Add mode
        modalTitle.innerHTML = `
            <span data-lang="fr">Ajouter un produit</span>
            <span data-lang="en">Add product</span>
            <span data-lang="ar">إضافة منتج</span>
        `;
        document.getElementById('productId').value = generateId('herb');
    }
    
    // Show modal
    productModal.style.display = 'block';
    
    // Update language display
    updateLanguageDisplay();
}

// Show category modal for adding or editing
function showCategoryModal(categoryId = null) {
    currentEditingId = categoryId;
    const modalTitle = document.getElementById('categoryModalTitle');
    
    // Reset form
    categoryForm.reset();
    
    if (categoryId) {
        // Edit mode
        const category = categoriesData.find(c => c.id === categoryId);
        if (!category) return;
        
        modalTitle.innerHTML = `
            <span data-lang="fr">Modifier la catégorie</span>
            <span data-lang="en">Edit category</span>
            <span data-lang="ar">تعديل الفئة</span>
        `;
        
        // Fill form with category data
        document.getElementById('categoryId').value = category.id;
        document.getElementById('categoryNameFr').value = category.name.fr;
        document.getElementById('categoryNameEn').value = category.name.en;
        document.getElementById('categoryNameAr').value = category.name.ar;
    } else {
        // Add mode
        modalTitle.innerHTML = `
            <span data-lang="fr">Ajouter une catégorie</span>
            <span data-lang="en">Add category</span>
            <span data-lang="ar">إضافة فئة</span>
        `;
        document.getElementById('categoryId').value = generateId('cat');
    }
    
    // Show modal
    categoryModal.style.display = 'block';
    
    // Update language display
    updateLanguageDisplay();
}

// Save product
function saveProduct(event) {
    event.preventDefault();
    
    const productId = document.getElementById('productId').value;
    const productNameFr = document.getElementById('productNameFr').value;
    const productNameEn = document.getElementById('productNameEn').value;
    const productNameAr = document.getElementById('productNameAr').value;
    const productDescFr = document.getElementById('productDescFr').value;
    const productDescEn = document.getElementById('productDescEn').value;
    const productDescAr = document.getElementById('productDescAr').value;
    const productUsageFr = document.getElementById('productUsageFr').value;
    const productUsageEn = document.getElementById('productUsageEn').value;
    const productUsageAr = document.getElementById('productUsageAr').value;
    const productBenefitsFr = document.getElementById('productBenefitsFr').value;
    const productBenefitsEn = document.getElementById('productBenefitsEn').value;
    const productBenefitsAr = document.getElementById('productBenefitsAr').value;
    const categoryId = document.getElementById('productCategory').value;
    const price = parseFloat(document.getElementById('productPrice').value);
    const currency = document.getElementById('productCurrency').value;
    const weight = document.getElementById('productWeight').value;
    const stock = parseInt(document.getElementById('productStock').value);
    const featured = document.getElementById('productFeatured').checked;
    
    // Find category
    const category = categoriesData.find(c => c.id === categoryId);
    
    if (!category) {
        showNotification('Veuillez sélectionner une catégorie valide', 'error');
        return;
    }
    
    // Create product object
    const product = {
        id: productId,
        name: {
            fr: productNameFr,
            en: productNameEn,
            ar: productNameAr
        },
        category: {
            fr: category.name.fr,
            en: category.name.en,
            ar: category.name.ar
        },
        price: price,
        currency: currency,
        image: 'images/products/placeholder.jpg', // Will be updated if image is uploaded
        description: {
            fr: productDescFr,
            en: productDescEn,
            ar: productDescAr
        },
        benefits: {
            fr: productBenefitsFr.split('\n').filter(b => b.trim() !== ''),
            en: productBenefitsEn.split('\n').filter(b => b.trim() !== ''),
            ar: productBenefitsAr.split('\n').filter(b => b.trim() !== '')
        },
        usage: {
            fr: productUsageFr,
            en: productUsageEn,
            ar: productUsageAr
        },
        stock: stock,
        featured: featured
    };
    
    // Add weight or volume
    if (weight) {
        if (weight.includes('ml') || weight.includes('l')) {
            product.volume = weight;
        } else {
            product.weight = weight;
        }
    }
    
    // Check if product already exists
    const existingProductIndex = productsData.findIndex(p => p.id === productId);
    
    if (existingProductIndex !== -1) {
        // Update existing product
        product.image = productsData[existingProductIndex].image; // Keep existing image if not changed
        productsData[existingProductIndex] = product;
        showNotification('Produit mis à jour avec succès', 'success');
    } else {
        // Add new product
        productsData.push(product);
        showNotification('Produit ajouté avec succès', 'success');
    }
    
    // Save to JSON file (in a real environment, this would be an API call)
    saveDataToJson();
    
    // Close modal and refresh products list
    productModal.style.display = 'none';
    renderProducts();
}

// Save category
function saveCategory(event) {
    event.preventDefault();
    
    const categoryId = document.getElementById('categoryId').value;
    const categoryNameFr = document.getElementById('categoryNameFr').value;
    const categoryNameEn = document.getElementById('categoryNameEn').value;
    const categoryNameAr = document.getElementById('categoryNameAr').value;
    
    // Create category object
    const category = {
        id: categoryId,
        name: {
            fr: categoryNameFr,
            en: categoryNameEn,
            ar: categoryNameAr
        }
    };
    
    // Check if category already exists
    const existingCategoryIndex = categoriesData.findIndex(c => c.id === categoryId);
    
    if (existingCategoryIndex !== -1) {
        // Update existing category
        categoriesData[existingCategoryIndex] = category;
        showNotification('Catégorie mise à jour avec succès', 'success');
    } else {
        // Add new category
        categoriesData.push(category);
        showNotification('Catégorie ajoutée avec succès', 'success');
    }
    
    // Save to JSON file (in a real environment, this would be an API call)
    saveDataToJson();
    
    // Close modal and refresh categories list
    categoryModal.style.display = 'none';
    renderCategories();
    populateCategoryDropdowns();
}

// Edit product
function editProduct(productId) {
    showProductModal(productId);
}

// Edit category
function editCategory(categoryId) {
    showCategoryModal(categoryId);
}

// Confirm delete product
function confirmDeleteProduct(productId) {
    const product = productsData.find(p => p.id === productId);
    if (!product) return;
    
    const message = `
        ${currentLanguage === 'fr' ? 'Êtes-vous sûr de vouloir supprimer le produit' : 
          currentLanguage === 'en' ? 'Are you sure you want to delete the product' : 
          'هل أنت متأكد أنك تريد حذف المنتج'} "${product.name[currentLanguage]}"?
    `;
    
    showConfirmModal(message, () => deleteProduct(productId));
}

// Delete product
function deleteProduct(productId) {
    const productIndex = productsData.findIndex(p => p.id === productId);
    if (productIndex === -1) return;
    
    productsData.splice(productIndex, 1);
    saveDataToJson();
    renderProducts();
    showNotification('Produit supprimé avec succès', 'success');
}

// Confirm delete category
function confirmDeleteCategory(categoryId) {
    const category = categoriesData.find(c => c.id === categoryId);
    if (!category) return;
    
    // Check if category is used by any product
    const productsUsingCategory = productsData.filter(p => 
        p.category.fr === category.name.fr || 
        p.category.en === category.name.en || 
        p.category.ar === category.name.ar
    );
    
    if (productsUsingCategory.length > 0) {
        showNotification(`Cette catégorie est utilisée par ${productsUsingCategory.length} produit(s) et ne peut pas être supprimée`, 'error');
        return;
    }
    
    const message = `
        ${currentLanguage === 'fr' ? 'Êtes-vous sûr de vouloir supprimer la catégorie' : 
          currentLanguage === 'en' ? 'Are you sure you want to delete the category' : 
          'هل أنت متأكد أنك تريد حذف الفئة'} "${category.name[currentLanguage]}"?
    `;
    
    showConfirmModal(message, () => deleteCategory(categoryId));
}

// Delete category
function deleteCategory(categoryId) {
    const categoryIndex = categoriesData.findIndex(c => c.id === categoryId);
    if (categoryIndex === -1) return;
    
    categoriesData.splice(categoryIndex, 1);
    saveDataToJson();
    renderCategories();
    populateCategoryDropdowns();
    showNotification('Catégorie supprimée avec succès', 'success');
}

// Show confirmation modal
function showConfirmModal(message, callback) {
    document.getElementById('confirmMessage').textContent = message;
    confirmCallback = callback;
    confirmModal.style.display = 'block';
}

// Handle image upload
function handleImageUpload() {
    const file = productImage.files[0];
    if (!file) return;
    
    // In a real environment, this would upload the file to a server
    // For this demo, we'll just show a preview
    const reader = new FileReader();
    reader.onload = function(e) {
        imagePreview.innerHTML = '';
        const img = document.createElement('img');
        img.src = e.target.result;
        img.alt = 'Product Image';
        imagePreview.appendChild(img);
        
        // In a real environment, we would save the image path
        // For this demo, we'll just update the product object
        if (currentEditingId) {
            const productIndex = productsData.findIndex(p => p.id === currentEditingId);
            if (productIndex !== -1) {
                // Generate a filename based on product name
                const productName = document.getElementById('productNameEn').value.toLowerCase().replace(/[^a-z0-9]/g, '_');
                const filename = `images/products/${productName}_${Date.now()}.jpg`;
                productsData[productIndex].image = filename;
            }
        }
    };
    reader.readAsDataURL(file);
}

// Load page content
function loadPageContent() {
    const page = pageSelect.value;
    const lang = languageSelect.value;
    
    // In a real environment, this would load content from files or database
    // For this demo, we'll just show a placeholder
    contentEditor.value = `# ${page} content in ${lang}\n\nThis is a placeholder for the ${page} page content in ${lang} language. In a real environment, this would load the actual content from files or a database.`;
}

// Save page content
function savePageContent() {
    const page = pageSelect.value;
    const lang = languageSelect.value;
    const content = contentEditor.value;
    
    // In a real environment, this would save content to files or database
    // For this demo, we'll just show a notification
    showNotification(`Contenu de la page ${page} en ${lang} enregistré avec succès`, 'success');
}

// Save settings
function saveSettings() {
    const siteName = document.getElementById('siteName').value;
    const contactEmail = document.getElementById('contactEmail').value;
    const contactPhone = document.getElementById('contactPhone').value;
    const contactAddress = document.getElementById('contactAddress').value;
    
    // In a real environment, this would save settings to a file or database
    // For this demo, we'll just show a notification
    showNotification('Paramètres enregistrés avec succès', 'success');
}

// Save data to JSON file
function saveDataToJson() {
    // In a real environment, this would be an API call to save data to a server
    // For this demo, we'll just log the data
    console.log('Saving data:', { products: productsData, categories: categoriesData });
    
    // In a real implementation, this would use fetch to send data to a server endpoint
    // that would save it to a JSON file or database
}

// Generate a unique ID
function generateId(prefix) {
    const timestamp = Date.now().toString().slice(-6);
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    return `${prefix}${timestamp}${random}`;
}

// Set language
function setLanguage(lang) {
    currentLanguage = lang;
    adminLanguageSelect.value = lang;
    
    // Set direction for RTL languages
    document.body.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');
    
    // Update language-specific elements
    updateLanguageDisplay();
    
    // Refresh data displays
    renderProducts();
    renderCategories();
    populateCategoryDropdowns();
}

// Update language display
function updateLanguageDisplay() {
    // Hide all language elements
    document.querySelectorAll('[data-lang]').forEach(el => {
        el.style.display = 'none';
    });
    
    // Show elements for current language
    document.querySelectorAll(`[data-lang="${currentLanguage}"]`).forEach(el => {
        el.style.display = 'inline';
    });
}

// Show notification
function showNotification(message, type = 'info') {
    // In a real implementation, this would show a toast notification
    // For this demo, we'll just use alert
    alert(message);
}

