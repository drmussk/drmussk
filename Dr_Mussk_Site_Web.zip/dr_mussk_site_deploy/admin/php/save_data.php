<?php
/**
 * Simple data save handler
 * 
 * This script handles saving data to JSON files for the admin panel
 * In a real environment, this would include more security checks
 */

// Set headers to allow cross-origin requests
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Get the request body
$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

// Check if data is valid
if ($data === null) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid JSON data'
    ]);
    exit;
}

// Check if data type is specified
if (!isset($data['type'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Data type not specified'
    ]);
    exit;
}

// Handle different data types
switch ($data['type']) {
    case 'products':
        if (!isset($data['products']) || !isset($data['categories'])) {
            echo json_encode([
                'success' => false,
                'message' => 'Products or categories data missing'
            ]);
            exit;
        }
        
        // Create data object
        $save_data = [
            'products' => $data['products'],
            'categories' => $data['categories']
        ];
        
        // Save to JSON file
        $result = file_put_contents('../../products.json', json_encode($save_data, JSON_PRETTY_PRINT));
        
        if ($result === false) {
            echo json_encode([
                'success' => false,
                'message' => 'Failed to save products data'
            ]);
        } else {
            echo json_encode([
                'success' => true,
                'message' => 'Products data saved successfully'
            ]);
        }
        break;
        
    case 'content':
        if (!isset($data['page']) || !isset($data['language']) || !isset($data['content'])) {
            echo json_encode([
                'success' => false,
                'message' => 'Page, language, or content data missing'
            ]);
            exit;
        }
        
        // Sanitize page name to prevent directory traversal
        $page = preg_replace('/[^a-zA-Z0-9_-]/', '', $data['page']);
        $language = preg_replace('/[^a-zA-Z0-9_-]/', '', $data['language']);
        
        // Create directory if it doesn't exist
        $content_dir = "../../content/$language/";
        if (!file_exists($content_dir)) {
            mkdir($content_dir, 0755, true);
        }
        
        // Save content to file
        $result = file_put_contents("$content_dir$page.md", $data['content']);
        
        if ($result === false) {
            echo json_encode([
                'success' => false,
                'message' => 'Failed to save content'
            ]);
        } else {
            echo json_encode([
                'success' => true,
                'message' => 'Content saved successfully'
            ]);
        }
        break;
        
    case 'settings':
        if (!isset($data['settings'])) {
            echo json_encode([
                'success' => false,
                'message' => 'Settings data missing'
            ]);
            exit;
        }
        
        // Save to JSON file
        $result = file_put_contents('../../settings.json', json_encode($data['settings'], JSON_PRETTY_PRINT));
        
        if ($result === false) {
            echo json_encode([
                'success' => false,
                'message' => 'Failed to save settings'
            ]);
        } else {
            echo json_encode([
                'success' => true,
                'message' => 'Settings saved successfully'
            ]);
        }
        break;
        
    default:
        echo json_encode([
            'success' => false,
            'message' => 'Unknown data type'
        ]);
        break;
}
?>

