<?php
/**
 * Simple file upload handler
 * 
 * This script handles file uploads for the admin panel
 * In a real environment, this would include more security checks
 */

// Set headers to allow cross-origin requests
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Define upload directory
$upload_dir = "../../images/products/";

// Create directory if it doesn't exist
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

// Check if file was uploaded
if (isset($_FILES['image'])) {
    $file = $_FILES['image'];
    
    // Check for errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        echo json_encode([
            'success' => false,
            'message' => 'Upload failed with error code: ' . $file['error']
        ]);
        exit;
    }
    
    // Check file type
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!in_array($file['type'], $allowed_types)) {
        echo json_encode([
            'success' => false,
            'message' => 'Only image files (JPG, PNG, GIF, WEBP) are allowed'
        ]);
        exit;
    }
    
    // Generate a unique filename
    $filename = uniqid() . '_' . basename($file['name']);
    $target_file = $upload_dir . $filename;
    
    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $target_file)) {
        echo json_encode([
            'success' => true,
            'message' => 'File uploaded successfully',
            'filename' => 'images/products/' . $filename
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to move uploaded file'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'No file uploaded'
    ]);
}
?>

