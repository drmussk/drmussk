<?php
/**
 * Simple content loader
 * 
 * This script handles loading content from files for the admin panel
 * In a real environment, this would include more security checks
 */

// Set headers to allow cross-origin requests
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Get parameters
$page = isset($_GET['page']) ? $_GET['page'] : '';
$language = isset($_GET['language']) ? $_GET['language'] : '';

// Validate parameters
if (empty($page) || empty($language)) {
    echo json_encode([
        'success' => false,
        'message' => 'Page or language parameter missing'
    ]);
    exit;
}

// Sanitize parameters to prevent directory traversal
$page = preg_replace('/[^a-zA-Z0-9_-]/', '', $page);
$language = preg_replace('/[^a-zA-Z0-9_-]/', '', $language);

// Build file path
$file_path = "../../content/$language/$page.md";

// Check if file exists
if (!file_exists($file_path)) {
    echo json_encode([
        'success' => false,
        'message' => 'Content file not found',
        'path' => $file_path
    ]);
    exit;
}

// Read file content
$content = file_get_contents($file_path);

if ($content === false) {
    echo json_encode([
        'success' => false,
        'message' => 'Failed to read content file'
    ]);
    exit;
}

// Return content
echo json_encode([
    'success' => true,
    'content' => $content
]);
?>

