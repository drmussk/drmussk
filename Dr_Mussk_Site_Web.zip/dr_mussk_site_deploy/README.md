# Site Web Dr. Mussk

Site web multilingue (arabe, français, anglais) pour Dr. Mussk, spécialisé dans la médecine alternative et les herbes.

## Fonctionnalités

- Site web responsive (adapté aux mobiles)
- Support multilingue (arabe, français, anglais)
- Boutique en ligne
- Interface d'administration pour gérer les produits et le contenu
- Système de panier d'achat

## Structure du site

- `/` - Version française (principale)
- `/en/` - Version anglaise
- `/ar/` - Version arabe
- `/admin/` - Interface d'administration

## Contact

Dr. Mussk
Adresse : South Lebanon, Tyre, Qana, Public Square
Téléphone : 0096171143147

